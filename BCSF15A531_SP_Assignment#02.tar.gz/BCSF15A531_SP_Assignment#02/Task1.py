import requests
import os,sys
import time
from PIL import Image
from bs4 import BeautifulSoup
from StringIO import StringIO
 
#getting  all names
def total_Qari(url):
	count=0
	req3=requests.get(url)
	obj1=BeautifulSoup(req3.content)
	totalqari=0
	if req3.status_code ==200:
		for k in obj1.find_all("a"):
			count=count+1
			
	return count
#getting items
def last_Items(URL):
	req1=requests.get(url)
	obj=BeautifulSoup(req1.content)
	names=[]
	if req1.status_code == 200:
		for i in obj.find_all("a"):
			names.append(i.text)
	return names

url3="https://download.quranicaudio.com/quran/"
f=open("logfile","w+")  #creating log file if not present, make it
count=0
c=0
count=total_Qari(url3)

out=str(time.strftime("%c"))+" "+"TOTAL QARI : "+str(count)  #represent in date and time format
f.write(out)
f.write("\n")
req=requests.get("https://download.quranicaudio.com/quran/")
if req.status_code == 200:   #successful request
	parser_obj = BeautifulSoup(req.content);
	
	for i in parser_obj.find_all("a"):
		path = i.text #returning links along with their link text
		
		if not os.path.exists(path):
			os.makedirs(path)
			os.chdir(path)
			url="https://download.quranicaudio.com/quran/"+path
			
			name =last_Items(url)
			c=c+1
			out=str(time.strftime("%c"))+" "+"Start Processing : "+str(c)+"out of "+str(count)
			f.write(out)
			f.write("\n")
			out=str(time.strftime("%c"))+" "+"Qari Name: "+str(path)
			f.write(out)
			f.write("\n")
		#getting last 26 files
			for j in name[-26:]:			
				url2= url+j
				out=str(time.strftime("%c"))+" "+"Qari Name : "+str(path)+" "+"Filename : "+str(j)+"START"
				f.write(out)
				f.write("\n")
				r = requests.get(url2)
				with open(j,"wb") as code:
					code.write(r.content)
				out=str(time.strftime("%c"))+" "+"Qari Name : "+str(path)+" "+"Filename : "+str(j)+"END"
				f.write(out)
				f.write("\n")
			out=str(time.strftime("%c"))+" "+"Merging file qari name : "+str(path)+" "+"START"
			f.write(out)
			f.write("\n")
			os.system("mp3wrap secondHalf.mp3 *.mp3")
			out=str(time.strftime("%c"))+" "+"Merging file qari name : "+str(path)+" "+"END"
			f.write(out)
			f.write("\n")	
					
		os.chdir("../")
							
						
					
			
				
		
			
	


    
    

  
	
