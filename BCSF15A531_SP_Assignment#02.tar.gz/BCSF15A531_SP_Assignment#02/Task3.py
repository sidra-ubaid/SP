listt =[    [11, 20, 31, 42, 3, 26, 37, 28], 
	  [91, 29, 37, 40, 12, 90, 43, 39], 
	  [1, 12, 10, 15, 14, 16, 97, 87], 
	  [23, 22, 47, 43, 59, 20, 59, 30], 
	  [26, 12, 35, 72, 10, 64, 45, 76], 
	  [78, 34, 24, 38, 55, 18, 25, 69], 
	  [55, 45, 23, 55, 11, 52, 33, 33], 
	  [49, 98, 7, 98, 65, 62, 92, 73]]

print "Taking a  Matrix as input.\n"

element00=raw_input("Enter an element for [0][0]: ")
element01=raw_input("Enter an element for [0][1]: ")
element10=raw_input("Enter an element for [1][0]: ")
element11=raw_input("Enter an element for [1][1]: ")
# convert in integer
ele00=int(element00)
ele01=int(element01)
ele10=int(element10)
ele11=int(element11)

c=0
for i in range(0,7):
	for j in range(0,7):
		if(listt[i][j] == ele00 and listt[i+1][j] == ele10 and listt[i][j+1] == ele01 and listt[i+1][j+1] == ele11):
			
			print "MATRIX FOUND : ({0},{1})".format(i+1,j+1)
			c=c+1
			
		
if(c is not 1):	
	print "MATRIX NOT FOUND\n"	

