import os
import psutil
import time

process_ID=input("ENTER PROCESS ID : ")
for process in psutil.process_iter():
	if(process.pid == process_ID):
		print "Process ID : {0}".format(process.pid)
		print "Process NAME : {0}".format(process.name)
		print "Process STATUS : {0}".format(process.status)
		print "Process PARENT ID : {0}".format(process.ppid)
		print "Process CREATION TIME : {0}".format(process.create_time)
		print "Process MEMORY INFO : {0}".format(process.get_memory_info)
		print "FILES OPENED BY PROCESS : {0}".format(process.get_open_files)
