#include<stdio.h>
#include <fcntl.h>

int main()
{
	int n;
	int buff[256];
	close(1);
	int fd1=open("f1",O_RDONLY|O_CREAT,0777);
	int d= dup2(fd1,2);

while(1)
{
	n=read(0,buff, 255);
	if(n<=0)
	{break;}
	write(d,buff,255);
}
return 0;
}
