#include<stdio.h>
#include <fcntl.h>

int main()
{
int n;
int fd1;
int fd2;
int fd3;
	char buff[1024];
	close(1);
	fd1=open("ErrorAndOutput",O_WRONLY|O_CREAT|O_TRUNC,0777);
	close(2);
	fd2=dup(fd1);
	 fd3 = open ("myfile", O_RDONLY);
	if(fd3<=0)
	{
		perror("ERROR");
		return; 
		//dup2(fd2,2);
	}
		//close(fd2);
	while(1)
{
	n = read (fd3, buff, 1023);
	if(n<=0)
	{break;}
	write(fd2, buff, n);
}

	
	return 0;
}
