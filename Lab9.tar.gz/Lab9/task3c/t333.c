#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
	int buff[256];
	close(0);
	int f0=open("f1",O_RDONLY);
	
	if(f0<=-1)
	{
		perror("ERROR");
	}
	int f2=dup2(1,2);
	int f1=open("f2",O_RDONLY | O_WRONLY |O_CREAT,0777);
	while(1)

	{
	int n=read("f1",buff,255);
	if(n<=0)
{break;}
write(f1,buff,n);
}
return 0;
}
