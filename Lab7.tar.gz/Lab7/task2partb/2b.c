#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main(int argc,char *argv[])
{
	int n1;
	int n2;
	int fd;
	int fd1;
	
	char buff[256];
	close(1);
	fd1=open(argv[1],O_CREAT | O_RDWR,0777);
	printf("print data before\n");
	fd=open("data file", O_RDONLY);
	printf("print data before\n");
 	
	while(1)
	{
		printf("print data before\n");
	
	 	n1=read(fd,buff,255);
	
		if(n1<=0)
		{
			break;

		}
		if(fd!=-1)
		{
			n2=write(fd1,buff,n1);
		}
	
		else
		{
	 		n2=write(1,buff,n1);
			if(n2==-1)
			{
				perror("Error in writing file\n");
				exit(1);
			}
	
		}
	
	 

	}
return 0;
}
