#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main(int argc,char *argv[])
{
	int n1;
	int n2;
	int fd;
	int fd1;
	
	char buff[256];
	 fd=open("/etc/passwd", O_RDONLY);
	
 	fd1=open(argv[1],O_CREAT | O_RDWR,0777);
	
	while(1)
{
	 n1=read(fd,buff,255);
	if(n1==-1)
{
	perror("Error in reading file\n");
	exit(1);

}
	 n2=write(fd1,buff,n1);
	if(n2==-1)
{
	perror("Error in writing file\n");
	exit(1);
}

}
return 0;
}
