#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main(int argc,char *argv[])
{
	int n1;
	int n2;
	
	int fd1;
	int fd2;
	
	char buff[256];
	
 	fd1=open(argv[1], O_RDWR,0777);
	fd2=open(argv[2],O_CREAT | O_RDWR,0777);
	
	while(1)
{
	 n1=read(fd1,buff,255);
	if(n1<=0)
	{
		printf("File name : %s",argv[1]);
		unlink(argv[1]);
		exit(1);
}
	if(n1==-1)
{
	perror("Error in reading file\n");
	exit(1);

}
	 n2=write(fd2,buff,n1);
	if(n2==-1)
{
	perror("Error in writing file\n");
	exit(1);
}

}

//unlink(argv[1]);
return 0;
}
