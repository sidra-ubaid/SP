#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main()
{
	int n1;
	int n2;
	int fd;
	char buff[256];
	 fd=open("file.txt",O_CREAT | O_RDWR);
	if(fd==-1)
	{
		perror("Error in creating file\n");
		exit(1);

}
	while(1)
{
	 n1=read(0,buff,255);
	if(n1==-1)
{
	perror("Error in reading file\n");
	exit(1);

}
	 n2=write(fd,buff,n1);
	if(n2==-1)
{
	perror("Error in writing file\n");
	exit(1);
}

}
return 0;
}
