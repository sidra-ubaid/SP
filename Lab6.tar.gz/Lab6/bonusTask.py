#write a program that displays actual calender on current month on console

import calendar
year=int(raw_input("Enter year: "))
month=int(raw_input("Enter month: "))

print(calendar.month(year,month)) 
