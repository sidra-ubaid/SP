#lines input and capitalize them

inputString=raw_input("Enter a string : ")

print inputString.upper()

