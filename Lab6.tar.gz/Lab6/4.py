#input words and sort them alphabetically



input=raw_input("Enter string: ")
list1=[]
list1=input.split(',')
list1.sort()
print list1
