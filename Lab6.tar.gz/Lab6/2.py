#with a given number , program to generate a dictionary that contains (i,i*i) such that is an integral number between 1 and number


dictionary={}
start=1
end=raw_input("Enter a number: ")
end=int(end)
while start!=end+1:
	dictionary[start]=start*start
	start=start+1
for key,value in dictionary.items():
	print "{0}:{1}".format(key,value)
print dictionary
