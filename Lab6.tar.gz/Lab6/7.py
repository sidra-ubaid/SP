#input a sentence and calculate numbers of letters and digits

input=raw_input("Enter string : " )
d=0
a=0
for n in input:
	if n.isdigit():

		d=d+1
	elif n.isalpha():
		a=a+1

print "Digits: ",d
print "Letters: ",a



