#input words and print after sorting them and removing all duplicates

input=raw_input("Enter string: ")
listt=input.split(' ')
sett=set(listt)
list1=list(sett)
list1.sort()
print list1
