#program which takes a sequence of comma separated numbers and generate a list and tuple which contain each number

input=raw_input("Enter numbers: ")
list1=[]
tuple1=[]
input.split(',')
list1.append(input)
tuple1=(list1)
print list1
print tuple1

