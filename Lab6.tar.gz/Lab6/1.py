#program that finds all numbers divisible by 7 but not multiple of 5 within given range.


def findNum():
	
	ran=range(2000,3200)
	result=[]
	for n in ran:
		if n % 7 == 0 and n % 5 != 0:
			result.append(n)
			

	print result

findNum()
