#include<stdio.h>
#include<signal.h>

int main()
{
	//signal(SIGINT,SIG_IGN);
	//signal(SIGFPE,SIG_IGN);
	//signal(SIGQUIT,SIG_IGN);
	
	signal(SIGHUP,SIG_IGN);
	while(1)
	{	
		printf("I am in infinite loop...\n");
		
		
	sleep(2);
	}
return 0;

}
