#include<stdio.h>
#include<signal.h>

int main()
{
	signal(SIGINT,SIG_IGN);
	//signal(SIGFPE,SIG_IGN);
	//signal(SIGQUIT,SIG_IGN);
	//signal(SIGHUP,SIG_IGN);
	while(1)
	{	
		printf("I am in infinite loop...\n");
		printf("You can't kill me by SIGINT <2> i.e by pressing CTRL+C> \n");
		printf("However you can kill me by SIGQUIT <3> i.e by pressing CTRL+\\ \n\n");
	sleep(2);
	}
return 0;

}
