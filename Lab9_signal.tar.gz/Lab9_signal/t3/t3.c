#include<stdio.h>
#include<signal.h>

void myhandler(int signum) 
{
	switch(signum)
	{
		case 2:
			printf("hey I got SIGINT : %d \n\n",signum);
			break;
		case 3:
			printf("hey I got SIGQUIT : %d \n\n",signum);
			break;
		case 20:
			printf("hey I got SIGTSTP : %d \n\n",signum);
			break;
		case 8:
			printf("hey I got SIGFPE : %d \n\n",signum);
			break;
		case 9:
			printf("hey I got SIGKILL : %d \n\n",signum);
			break;
		case 19:
			printf("hey I got SIGSTOP : %d \n\n",signum);
			break;
}
}

int main()
{
	signal(SIGINT,myhandler);
	signal(SIGQUIT,myhandler);
	signal(SIGTSTP,myhandler);
	signal(SIGSTOP,myhandler);
	signal(SIGFPE,myhandler);
	signal(SIGKILL,myhandler);
	while(1)
	{	
		printf("I am in an infinite loop\n");
		sleep(1);
	}
	
return 0;
}
