#include<stdio.h>
#include<signal.h>

int main()
{
	
	signal(SIGFPE,SIG_IGN);
	float ans=44/0;
	kill(getpid(),SIGFPE);
	raise(SIGFPE);
	while(1)
	{	
		printf("I am still running  loop because i have ignored signal...\n");
		sleep(2);
	}
return 0;

}
