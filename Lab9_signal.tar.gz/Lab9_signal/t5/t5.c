#include<stdio.h>

int main()
{
	printf("This is my cronjob file.\n");
	return 0;
}

//Procedure:

//	crontab -e

//	*/3 * * * * echo "hello" >>/home/sidra/Desktop/data.txt
//to save CTRL+X

//Requirement:
 //  0 3 * * 1,2,3,4,5 >>/home/sidra/Desktop/Lab9_signal/t5/./a.out
