#include<stdio.h>
#include<signal.h>

int main()
{
	//signal(SIGINT,SIG_IGN);
	//signal(SIGFPE,SIG_IGN);
	//signal(SIGQUIT,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);
	//signal(SIGHUP,SIG_IGN);
	while(1)
	{	
		printf("I am in infinite loop...\n");
		printf("You can't kill me by SIGTSTP <2> i.e by pressing CTRL+Z> \n");
		sleep(2);
	}
return 0;

}
