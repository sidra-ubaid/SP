#include<stdio.h>
#include<signal.h>
#include<sys/types.h>

int main()
{
	sigset_t newset, oldset;
	sigemptyset(&newset);
	sigaddset(&newset,SIGINT);
	sigprocmask(SIG_SETMASK, &newset, &oldset);
int i=0;

	for(i=1;i<=10;i++)
	{
		printf("I am in  an infinite loop for 10 sec with new sigset which is masking SIGINT.\n");
		sleep(1);
	}

sigprocmask(SIG_SETMASK, &oldset, NULL);
int j=0;
for(j=1;j<=10;j++)
	{
		printf("I am in  an infinite loop for 10 sec with old sigset which is not masking SIGINT.\n");
		sleep(1);
	}



return 0;
}
