#include<stdio.h>
#include<signal.h>
#include<sys/types.h>

int main()
{
	pid_t cpid=fork();
	if (cpid==0)
	{
		for( ; ; )
		{	
			printf("I am child in an infinite loop\n");
			sleep(1);
		}
	}
	else
	{
		sleep(5);
		kill(cpid,SIGINT);
		printf("I have killed my child ...BYE\n");
		exit(0);
		
	}


return 0;
}
